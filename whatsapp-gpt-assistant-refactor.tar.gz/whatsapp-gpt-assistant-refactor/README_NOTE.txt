NOTE:
- This zip contains a refactored WhatsApp GPT assistant with connectors and helpers.
- Features: voice transcription, intent routing, event create with confirmation, event update with disambiguation, tasks connector skeleton (Any.do placeholder + Google Tasks fallback stubs).
- Configure .env and Google OAuth (Desktop) as before. Any.do API is left as NotImplemented unless you provide ANYDO_BASE_URL and ANYDO_TOKEN plus actual endpoints.
